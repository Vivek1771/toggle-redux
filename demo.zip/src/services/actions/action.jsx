export const SWITCH = "SWITCH";

export const switchto = () => {
  return {
    type: SWITCH,
  };
};
